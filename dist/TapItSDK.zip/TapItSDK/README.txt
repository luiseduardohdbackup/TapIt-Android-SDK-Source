TapIt Android SDK
Version 2.0.1

Complete implementation instructions can be found at:
https://github.com/tapit/TapIt-Android-SDK-Source
