TapIt Android SDK
Version 1.8.0

Complete implementation instructions can be found at:
https://github.com/tapit/TapIt-Android-SDK-Source
