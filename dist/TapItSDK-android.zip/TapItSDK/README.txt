TapIt Android SDK
Version 1.7.9

Complete implementation instructions can be found at:
https://github.com/tapit/TapIt-Android-SDK-Source

